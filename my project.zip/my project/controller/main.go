// controller/main.go
package main

import (
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "sync"
    "time"
    "github.com/google/uuid"
)

type ReplicaInfo struct {
    ID        string    json:"id"
    StartTime time.Time json:"start_time"
}

type ServiceClusterState struct {
    ServiceName string        json:"service_name"
    Replicas    []ReplicaInfo json:"replicas"
}

var (
    mu         sync.Mutex
    clusterMap = make(map[string][]ReplicaInfo) // ключ: название сервиса, значение: список реплик
    agentNodes = []string{"http://host1:8090", "http://host2:8090"} // список агентов
)

// API для развертывания N реплик сервиса
func handleDeploy(w http.ResponseWriter, r *http.Request) {
    var req struct {
        ServiceName string json:"service_name"
        Count       int    json:"count"
    }
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }

    mu.Lock()
    defer mu.Unlock()

    currentCount := len(clusterMap[req.ServiceName])
    delta := req.Count - currentCount
    if delta > 0 {
        // запуск дополнительных реплик
        for i := 0; i < delta; i++ {
            id := uuid.New().String()
            replica := ReplicaInfo{
                ID:        id,
                StartTime: time.Now(),
            }
            // Отправка запроса на запуск к агенту
            agent := agentNodes[(currentCount+i)%len(agentNodes)]
            startReq := struct {
                Action      string json:"action" // "start"
                ServiceName string json:"service_name"
                ConfigURL   string json:"config_url"
            }{
                Action:      "start",
                ServiceName: req.ServiceName,
                ConfigURL:   "https://storage.example.com/configs/workload-config",
            }
            jsonData, _ := json.Marshal(startReq)
            http.Post(fmt.Sprintf("%s/command", agent), "application/json", json.NewDecoder(bytes.NewReader(jsonData)))

            // добавляем в состояние
            clusterMap[req.ServiceName] = append(clusterMap[req.ServiceName], replica)
        }
    } else if delta < 0 {
        // остановить лишние реплики
        toRemove := -delta
        replicas := clusterMap[req.ServiceName]
        for i := 0; i < toRemove && len(replicas) > 0; i++ {
            replica := replicas[len(replicas)-1]
            // Отправка запроса на остановку
            agent := agentNodes[(len(replicas)-1)%len(agentNodes)]
            stopReq := struct {
                Action      string json:"action" // "stop"
                ServiceName string json:"service_name"
                ConfigURL   string json:"config_url"
            }{
                Action:      "stop",
                ServiceName: req.ServiceName,
                ConfigURL:   "",
            }
            jsonData, _ := json.Marshal(stopReq)
            http.Post(fmt.Sprintf("%s/command", agent), "application/json", json.NewDecoder(bytes.NewReader(jsonData)))

            // Убираем из состояния
            replicas = replicas[:len(replicas)-1]
        }
        clusterMap[req.ServiceName] = replicas
    }

    w.WriteHeader(http.StatusOK)
    json.NewEncoder(w).Encode(struct {
        Message string json:"message"
    }{"Deployment completed"})
}

// API для получения состояния кластера
func handleStatus(w http.ResponseWriter, r *http.Request) {
    mu.Lock()
    defer mu.Unlock()

    var status []ServiceClusterState
    for serviceName, replicas := range clusterMap {
        status = append(status, ServiceClusterState{
            ServiceName: serviceName,
            Replicas:    replicas,
        })
    }
    json.NewEncoder(w).Encode(status)
}

// Основной цикл и запуск
func main() {
    http.HandleFunc("/deploy", handleDeploy)
    http.HandleFunc("/status", handleStatus)
    // запустим периодический сбор данных о сервисах (можно убрать, если не нужно)
    go func() {
        for {
            // Можно реализовать обнаружение сервисов, обновление карты и т.д.
            time.Sleep(15 * time.Second)
        }
    }()

    fmt.Println("Controller listening on :8000")
    if err := http.ListenAndServe(":8000", nil); err != nil {
        log.Fatal(err)
    }
}