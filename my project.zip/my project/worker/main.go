package main

import (
	"fmt"
	"log"
	"net/http"
)

func workloadHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Workload is running")
}

func main() {
	http.HandleFunc("/", workloadHandler)
	log.Println("Workload service started on :8080")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal(err)
	}
}
